﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductsAndCategory_Mongodb_17March.Models;
using ProductsAndCategory_Mongodb_17March.Services;

namespace ProductsAndCategory_Mongodb_17March.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("swagger")]
    public class ProductAndCategoryController : ControllerBase
    {
        private readonly ProductAndCategoryService _productandcategoryService;

        public ProductAndCategoryController(ProductAndCategoryService productandcategoryService)
        {
            _productandcategoryService = productandcategoryService;
        }
        [HttpGet]
        public async Task<List<ProductsAndCategories>> Get() =>
            await _productandcategoryService.GetAsync();
        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<ProductsAndCategories>> Get(string id)
        {
            var book = await _productandcategoryService.GetAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            return book;
        }

        [HttpGet("CategoryName")]
        public async Task<ActionResult<ProductsAndCategories>> GetCategoryName(string CategoryName)
        {
            var catpro = await _productandcategoryService.GetAsyncOne(CategoryName);
            if (catpro is null)
            {
                return NotFound();
            }
            return catpro;
        }
        [HttpPost]
        public async Task<IActionResult> Post(ProductsAndCategories newProductAndCategories)
        {
            await _productandcategoryService.CreateAsync(newProductAndCategories);
            return CreatedAtAction(nameof(Get), new { id = newProductAndCategories.id }, newProductAndCategories);
        }
        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update(string id, ProductsAndCategories updatedProductsAndCategories)
        {
            var product = await _productandcategoryService.GetAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            updatedProductsAndCategories.id = product.id;
            await _productandcategoryService.UpdateAsync(id, updatedProductsAndCategories);
            return NoContent();
        }
        [HttpDelete("{id:length(24)}")]
        public async Task<IActionResult> Delete(string id)
        {
            var book = await _productandcategoryService.GetAsync(id);
            if (book is null)
            {
                return NotFound();
            }
            await _productandcategoryService.RemoveAsync(id);
            return NoContent();
        }
    }
}
