﻿namespace ProductsAndCategory_Mongodb_17March.Models
{
    public class ProductAndCategoryStoreSetting
    {
        public string ConnectionString { get; set; } = null;
        public string DatabaseName { get; set; } = null;
        public string ProductsAndCategoriesCollectionName { get; set; } = null;
    }
}
