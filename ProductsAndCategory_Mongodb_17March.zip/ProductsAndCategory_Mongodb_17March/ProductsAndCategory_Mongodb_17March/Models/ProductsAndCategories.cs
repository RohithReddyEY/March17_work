﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace ProductsAndCategory_Mongodb_17March.Models
{
    public class ProductsAndCategories
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? id { get; set; }
        [BsonElement("ProductName")]
        public string ProductName { get; set; }
        public int ProductAmount { get; set; }
        public string ProductReview { get; set; }

      public int ? CategoryId { get; set; }
        public string CategoryName { get; set;}
        public int CategoryQuantity { get; set;}


    }
}
