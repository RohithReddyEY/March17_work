﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using ProductsAndCategory_Mongodb_17March.Models;
namespace ProductsAndCategory_Mongodb_17March.Services
{
    public class ProductAndCategoryService
    {
        private readonly IMongoCollection<ProductsAndCategories> _productsandcategoriesCollection;
        public ProductAndCategoryService(IOptions<ProductAndCategoryStoreSetting> productandcategoryStoreSetting)
        {
            var mongoClient = new MongoClient(
                productandcategoryStoreSetting.Value.ConnectionString);//this represents connection string
            var mongoDatabase = mongoClient.GetDatabase(
                productandcategoryStoreSetting.Value.DatabaseName);//get my database
            _productsandcategoriesCollection = mongoDatabase.GetCollection<ProductsAndCategories>(
                productandcategoryStoreSetting.Value.ProductsAndCategoriesCollectionName);//get my collection
        }
        public async Task<List<ProductsAndCategories>> GetAsync() =>
           await _productsandcategoriesCollection.Find(_ => true).ToListAsync();
        public async Task<ProductsAndCategories> GetAsync(string id) =>
           await _productsandcategoriesCollection.Find(x => x.id == id).FirstOrDefaultAsync();
        public async Task<ProductsAndCategories> GetAsyncOne(string CategoryName) =>
            await _productsandcategoriesCollection.Find(x => x.CategoryName == CategoryName).FirstOrDefaultAsync();

        public async Task CreateAsync(ProductsAndCategories productandcategories) =>
            await _productsandcategoriesCollection.InsertOneAsync(productandcategories);

        public async Task UpdateAsync(string id, ProductsAndCategories updatedproductandcategory) =>
            await _productsandcategoriesCollection.ReplaceOneAsync(x => x.id == id, updatedproductandcategory);

        public async Task RemoveAsync(string id) =>
            await _productsandcategoriesCollection.DeleteOneAsync(x => x.id == id);

    }
}
